<?php
// resources/lang/en/nav.php
return [
    'home'      => 'Home',
    'about'     => 'About Us',
    'services'  => 'Practice Areas',
    'team'      => 'Our Team',
    'articles'  => 'Articles',
    'contact'   => 'Contact',
    'misc'      => 'Miscellaneous',
    // --- UPDATE THE LINES BELOW ---
    'bi'        => 'Business Intelligence',
    'set'       => 'Service Estimation Time',
];