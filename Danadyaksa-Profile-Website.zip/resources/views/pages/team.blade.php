{{-- /resources/views/pages/team.blade.php --}}
@extends('layouts.app')

@section('title', 'Our Team - Danadyaksa 08 Law Firm')

@section('content')

    {{-- Header Section --}}
    <section class="relative z-0 bg-gradient-to-r from-primaryDark to-primary text-white text-center pt-32 pb-16">
        <div class="container mx-auto px-4">
            <h1 class="text-4xl md:text-5xl font-bold">Meet Our Legal Experts</h1>
        </div>
    </section>

    {{-- Main content section --}}
    <section id="team-content" class="py-16 md:py-24 bg-surface overflow-hidden">
        <div class="container mx-auto px-4">
            <div class="text-center">
                <p class="text-lg text-gray-600 mb-12 max-w-2xl mx-auto">Our strength lies in our team of dedicated and experienced legal professionals who are committed to achieving the best results for our clients.</p>
            </div>
            
            <div class="swiper team-swiper">
                <div class="swiper-wrapper pb-16">
                    
                    {{-- Lawyer Profile Card 1 (Slide) --}}
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg p-6 text-center h-full flex flex-col">
                            <img src="{{ asset('images/team-member-1.jpg') }}" alt="Team Member Name" class="w-32 h-32 rounded-full mx-auto mb-4 object-cover">
                            <h3 class="text-xl font-bold text-gray-900">Founder Name</h3>
                            <p class="text-primary font-semibold mb-3">Managing Partner</p>
                            <p class="text-gray-600 text-sm flex-grow">
                                With decades of experience in litigation and corporate law, our managing partner provides strategic leadership and is dedicated to the firm's founding vision of mentorship and excellence.
                            </p>
                        </div>
                    </div>
                    
                    {{-- Lawyer Profile Card 2 (Slide) --}}
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg p-6 text-center h-full flex flex-col">
                            <img src="{{ asset('images/team-member-2.jpg') }}" alt="Team Member Name" class="w-32 h-32 rounded-full mx-auto mb-4 object-cover">
                            <h3 class="text-xl font-bold text-gray-900">Lawyer Name</h3>
                            <p class="text-primary font-semibold mb-3">Senior Associate</p>
                            <p class="text-gray-600 text-sm flex-grow">
                                A specialist in commercial dispute resolution and arbitration, offering insightful and effective strategies to resolve complex conflicts for our corporate clients.
                            </p>
                        </div>
                    </div>
                    
                    {{-- Lawyer Profile Card 3 (Slide) --}}
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg p-6 text-center h-full flex flex-col">
                            <img src="{{ asset('images/team-member-3.jpg') }}" alt="Team Member Name" class="w-32 h-32 rounded-full mx-auto mb-4 object-cover">
                            <h3 class="text-xl font-bold text-gray-900">Lawyer Name</h3>
                            <p class="text-primary font-semibold mb-3">Litigation Specialist</p>
                            <p class="text-gray-600 text-sm flex-grow">
                                An expert in criminal and administrative law, known for meticulous case preparation and powerful advocacy in the courtroom.
                            </p>
                        </div>
                    </div>
                    
                    {{-- Lawyer Profile Card 4 (Slide) --}}
                    <div class="swiper-slide">
                        <div class="bg-white rounded-lg shadow-lg p-6 text-center h-full flex flex-col">
                            <img src="{{ asset('images/team-member-4.jpg') }}" alt="Team Member Name" class="w-32 h-32 rounded-full mx-auto mb-4 object-cover">
                            <h3 class="text-xl font-bold text-gray-900">Lawyer Name</h3>
                            <p class="text-primary font-semibold mb-3">Corporate Counsel</p>
                            <p class="text-gray-600 text-sm flex-grow">
                                Focused on non-litigation matters, providing expert legal drafting, opinions, and consultation for clients in the mining and plantation sectors.
                            </p>
                        </div>
                    </div>

                    {{-- Add more swiper-slide divs for more team members --}}

                </div>
                <div class="swiper-pagination"></div>

                <div class="swiper-button-prev text-primary"></div>
                <div class="swiper-button-next text-primary"></div>
            </div>
        </div>
    </section>

@endsection

@push('scripts')
{{-- This script initializes the SwiperJS carousel --}}
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const swiper = new Swiper('.team-swiper', {
            // How many slides to show at once
            slidesPerView: 1,
            // Space between slides
            spaceBetween: 30,
            // Enable looping
            loop: true,

            // Responsive breakpoints
            breakpoints: {
                // when window width is >= 768px
                768: {
                    slidesPerView: 2,
                    spaceBetween: 30
                },
                // when window width is >= 1024px
                1024: {
                    slidesPerView: 3,
                    spaceBetween: 40
                }
            },

            // Optional: Pagination bullets
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },

            // Optional: Navigation arrows
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    });
</script>
@endpush