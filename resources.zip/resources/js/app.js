import './bootstrap'; // Laravel's default bootstrap.js (if any)

// Your main JavaScript for the profile site
console.log('Profile website JS loaded!');

// You can add more advanced JS here, e.g.,
// Intersection Observer for scroll-reveal animations
// Image lazy loading
// Form validation
// Dynamic content loading (AJAX)

// Example: Simple "scroll-to-top" button (optional)
const scrollToTopBtn = document.createElement('button');
scrollToTopBtn.innerHTML = '&uarr;'; // Up arrow
scrollToTopBtn.classList.add('fixed', 'bottom-8', 'right-8', 'bg-indigo-600', 'text-white', 'p-3', 'rounded-full', 'shadow-lg', 'hidden', 'transition-all', 'duration-300', 'hover:bg-indigo-700', 'focus:outline-none');
document.body.appendChild(scrollToTopBtn);

window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        scrollToTopBtn.classList.remove('hidden');
        scrollToTopBtn.classList.add('scale-100', 'opacity-100');
    } else {
        scrollToTopBtn.classList.remove('scale-100', 'opacity-100');
        scrollToTopBtn.classList.add('hidden');
    }
});

scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});