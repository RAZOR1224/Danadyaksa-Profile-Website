<?php
// resources/lang/id/nav.php
return [
    'home'      => 'Beranda',
    'about'     => 'Tentang Kami',
    'services'  => 'Area Praktik',
    'team'      => 'Tim Kami',
    'articles'  => 'Artikel',
    'contact'   => 'Kontak',
];