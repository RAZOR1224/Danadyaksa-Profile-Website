<footer class="bg-gray-900 text-white py-8 mt-12">
    <div class="container mx-auto text-center px-4">
        <p>&copy; {{ date('Y') }} Your Name. All rights reserved.</p>
        <div class="flex justify-center space-x-4 mt-4">
            <a href="#" class="text-gray-400 hover:text-white transition duration-300">LinkedIn</a>
            <a href="#" class="text-gray-400 hover:text-white transition duration-300">GitHub</a>
            <a href="#" class="text-gray-400 hover:text-white transition duration-300">Twitter</a>
        </div>
    </div>
</footer>