{{-- /resources/views/partials/header.blade.php --}}

<header 
    x-data="{ open: false, scrolled: false }"
    x-init="scrolled = window.scrollY > 50"
    @scroll.window="scrolled = window.scrollY > 50"
    :class="{ 'bg-white shadow-md': scrolled, 'bg-transparent text-white': !scrolled }"
    class="transition-colors duration-300"
    id="page-header"
>
    <nav class="container mx-auto flex justify-between items-center px-4 h-20">
        
        {{-- Brand/Logo Section --}}
        <a href="{{ route('home', app()->getLocale()) }}" class="flex items-center">
            <img src="{{ asset('images/logo.png') }}" alt="Danadyaksa 08 Law Firm Logo" class="h-10 mr-3">
            <span class="text-2xl font-bold" :class="{ 'text-gray-900': scrolled, 'text-white': !scrolled }">
                DANADYAKSA <span class="text-accent">08</span>
            </span>
        </a>

        {{-- Right side of Navbar --}}
        <div class="hidden md:flex items-center space-x-6">
            {{-- Desktop Menu (Updated with translation helpers) --}}
            <ul class="flex items-center space-x-8">
                <li><a href="{{ route('home', app()->getLocale()) }}" :class="{ 'text-gray-700 hover:text-primary': scrolled, 'hover:text-gray-300': !scrolled }" class="font-medium transition-colors">{{ __('nav.home') }}</a></li>
                <li><a href="{{ route('about', app()->getLocale()) }}" :class="{ 'text-gray-700 hover:text-primary': scrolled, 'hover:text-gray-300': !scrolled }" class="font-medium transition-colors">{{ __('nav.about') }}</a></li>
                <li><a href="{{ route('services', app()->getLocale()) }}" :class="{ 'text-gray-700 hover:text-primary': scrolled, 'hover:text-gray-300': !scrolled }" class="font-medium transition-colors">{{ __('nav.services') }}</a></li>
                <li><a href="{{ route('team', app()->getLocale()) }}" :class="{ 'text-gray-700 hover:text-primary': scrolled, 'hover:text-gray-300': !scrolled }" class="font-medium transition-colors">{{ __('nav.team') }}</a></li>
                <li><a href="{{ route('articles', app()->getLocale()) }}" :class="{ 'text-gray-700 hover:text-primary': scrolled, 'hover:text-gray-300': !scrolled }" class="font-medium transition-colors">{{ __('nav.articles') }}</a></li>
                <li><a href="{{ route('contact', app()->getLocale()) }}" :class="{ 'text-gray-700 hover:text-primary': scrolled, 'hover:text-gray-300': !scrolled }" class="font-medium transition-colors">{{ __('nav.contact') }}</a></li>
            </ul>

            {{-- Language Switcher Dropdown --}}
            <div class="relative" x-data="{ langOpen: false }">
                <button @click="langOpen = !langOpen" class="flex items-center font-medium transition-colors p-2 rounded-md" :class="{ 'text-gray-700 hover:bg-gray-100': scrolled, 'hover:bg-white/10': !scrolled }">
                    <span>{{ strtoupper(app()->getLocale()) }}</span>
                    <i class="fas fa-chevron-down ml-2 text-xs transition-transform" :class="{ 'rotate-180': langOpen }"></i>
                </button>
                <div x-show="langOpen" @click.away="langOpen = false" class="absolute top-full right-0 mt-2 bg-white rounded-md shadow-lg py-1 z-10 w-32" style="display: none;">
                    <a href="{{ route(request()->route()->getName() ?: 'home', 'en') }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">English (EN)</a>
                    <a href="{{ route(request()->route()->getName() ?: 'home', 'id') }}" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Indonesia (ID)</a>
                </div>
            </div>
        </div>

        {{-- Mobile Menu Button --}}
        <button @click="open = !open" class="md:hidden focus:outline-none" :class="{ 'text-gray-900': scrolled, 'text-white': !scrolled }">
            <svg x-show="!open" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
            <svg x-show="open" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
    </nav>

    {{-- Mobile Dropdown Menu (Updated with translation helpers) --}}
    <div x-show="open" @click.away="open = false" class="md:hidden bg-white shadow-lg">
        <ul class="py-2 text-gray-700">
            <li><a href="{{ route('home', app()->getLocale()) }}" class="block px-4 py-2 hover:bg-gray-100">{{ __('nav.home') }}</a></li>
            <li><a href="{{ route('about', app()->getLocale()) }}" class="block px-4 py-2 hover:bg-gray-100">{{ __('nav.about') }}</a></li>
            <li><a href="{{ route('services', app()->getLocale()) }}" class="block px-4 py-2 hover:bg-gray-100">{{ __('nav.services') }}</a></li>
            <li><a href="{{ route('team', app()->getLocale()) }}" class="block px-4 py-2 hover:bg-gray-100">{{ __('nav.team') }}</a></li>
            <li><a href="{{ route('articles', app()->getLocale()) }}" class="block px-4 py-2 hover:bg-gray-100">{{ __('nav.articles') }}</a></li>
            <li><a href="{{ route('contact', app()->getLocale()) }}" class="block px-4 py-2 hover:bg-gray-100">{{ __('nav.contact') }}</a></li>
            <hr class="my-2">
            <li class="px-4 py-2 text-sm text-gray-500">Switch Language:</li>
            <li><a href="{{ route(request()->route()->getName() ?: 'home', 'en') }}" class="block px-4 py-2 hover:bg-gray-100 @if(app()->getLocale() == 'en') font-bold text-primary @endif">English (EN)</a></li>
            <li><a href="{{ route(request()->route()->getName() ?: 'home', 'id') }}" class="block px-4 py-2 hover:bg-gray-100 @if(app()->getLocale() == 'id') font-bold text-primary @endif">Indonesia (ID)</a></li>
        </ul>
    </div>
</header>